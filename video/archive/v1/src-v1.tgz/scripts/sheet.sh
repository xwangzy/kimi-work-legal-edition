#!/bin/bash
# 用法：scripts/sheet.sh <合成ID> <输出名> <帧1> <帧2> ...  —— 渲染若干静帧并拼成 2 列联系表（检查用）
set -e
cd "$(dirname "$0")/.."
comp=$1; name=$2; shift 2
mkdir -p out/sheets/tmp
files=()
for fr in "$@"; do
  npx remotion still src/index.ts "$comp" "out/sheets/tmp/${name}-${fr}.png" --frame="$fr" --scale=0.5 --log=error >/dev/null
  files+=("out/sheets/tmp/${name}-${fr}.png")
done
n=${#files[@]}
inputs=""; for f in "${files[@]}"; do inputs="$inputs -i $f"; done
cols=2; rows=$(( (n + cols - 1) / cols ))
layout=""; for ((i=0;i<n;i++)); do x=$(( i % cols )); y=$(( i / cols )); layout="$layout${layout:+|}$(( x*960 ))_$(( y*540 ))"; done
if [ "$n" -eq 1 ]; then cp "${files[0]}" "out/sheets/${name}.png"; else
ffmpeg -y -loglevel error $inputs -filter_complex "xstack=inputs=$n:layout=$layout:fill=black" "out/sheets/${name}.png"; fi
echo "out/sheets/${name}.png"
