/**
 * S6 · 发出之前，先换成代号：产品的“开始前确认”对话框。
 * 预览框里的自然人姓名、证件号在发送前替换为〔类别·6位〕代号，机构名称保留原文（与 packages/tokenizer 的规则一致）。
 */
import type { ReactNode } from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { easeInOut, lerp, prog, spr } from "../lib/anim";
import { Cursor, Headline, ProductStage, StudioBackdrop, type CamKey } from "../ui/film";
import { Icon } from "../ui/Icons";
import { TokenChip } from "../ui/product";
import { HOME_END_CAM, HOME_TASK, HomeWindow } from "./S05Home";

import { PRIVACY_CLICK, PRIVACY_REDACT } from "../cues.ts";

const CAM: CamKey[] = [
  { ...HOME_END_CAM, f: 0 },
  { f: 14, fx: 720, fy: 450, s: 1.06, rx: 0, ry: 0, ox: 0, oy: 0 },
  { f: 50, fx: 720, fy: 405, s: 1.9, rx: 0, ry: 0, ox: 0, oy: 0 },
  { f: 116, fx: 720, fy: 412, s: 1.98, rx: 0, ry: 0, ox: 0, oy: 0 },
  { f: 146, fx: 720, fy: 470, s: 1.0, rx: 2, ry: -10, ox: 560, oy: 10 },
  { f: 192, fx: 720, fy: 470, s: 1.03, rx: 2, ry: -9, ox: 550, oy: 10 },
];

/** 一处敏感信息：先被标出，再收拢成代号。 */
function Redact({ f, at, text, kind, code, em }: { f: number; at: number; text: string; kind: string; code: string; em: number }) {
  const mark = prog(f, at, 14);
  const swap = prog(f, at + 18, 18, easeInOut);
  const pop = spr(f, at + 22, 200, 18);
  if (swap < 0.5) {
    return (
      <span
        style={{
          backgroundImage: "linear-gradient(var(--paper-mark-person), var(--paper-mark-person))",
          backgroundRepeat: "no-repeat",
          backgroundSize: `${mark * 100}% 100%`,
          boxShadow: mark > 0.98 ? "inset 0 -2px 0 var(--paper-mark-line-high)" : undefined,
          borderRadius: 3,
          filter: `blur(${swap * 6}px)`,
          opacity: 1 - swap * 0.6,
        }}
      >
        {text}
      </span>
    );
  }
  return (
    <span style={{ display: "inline-block", maxWidth: `${lerp(em, 13, prog(f, at + 26, 14, easeInOut))}em`, overflow: "hidden", verticalAlign: "bottom", whiteSpace: "nowrap" }}>
      <TokenChip kind={kind} code={code} style={{ transform: `scale(${0.8 + 0.2 * pop})`, opacity: Math.min(1, pop * 1.4) }} />
    </span>
  );
}

function Org({ children, f, at }: { children: ReactNode; f: number; at: number }) {
  const p = prog(f, at, 16);
  return <span style={{ boxShadow: `inset 0 -${2 * p}px 0 var(--paper-mark-label-org)`, background: `rgba(234,242,255,${p})`, borderRadius: 3 }}>{children}</span>;
}

export function ConfirmModal({ f, appear = 0, startPressed = 0 }: { f: number; appear?: number; startPressed?: number }) {
  const p = spr(f, appear, 170, 22);
  const done = prog(f, 110, 14);
  return (
    <div style={{ position: "absolute", inset: 0, zIndex: 30 }}>
      <div style={{ position: "absolute", inset: 0, background: "var(--bg-overlay)", opacity: Math.min(1, p * 1.3) }} />
      <div className="modal" style={{ position: "absolute", left: 720 - 290, top: 128, width: 580, maxHeight: "none", overflow: "visible", opacity: Math.min(1, p * 1.5), transform: `translateY(${(1 - p) * 24}px) scale(${0.97 + 0.03 * p})` }}>
        <div className="modal-head">
          <span>开始前确认</span>
          <span style={{ color: "var(--text-label)", display: "inline-flex" }}><Icon.x /></span>
        </div>
        <div className="modal-body">
          <dl className="cc-body" style={{ gridTemplateColumns: "96px 1fr", margin: "0 0 10px" }}>
            <dt>事项</dt>
            <dd>甲公司股权转让（受让方）</dd>
            <dt>做什么</dt>
            <dd>审合同 · 股权转让协议.docx</dd>
            <dt>运行模式</dt>
            <dd>标准（推荐）· 先出计划</dd>
            <dt>内容会发给谁</dt>
            <dd>任务说明与必要的材料片段 → Kimi 模型（经中软法律模型网关）。自然人姓名、证件号、账户与联系方式在发送前替换为代号，机构名称保留原文；每一次外发都记入数据去向。</dd>
          </dl>
          <div className="cc-send" style={{ padding: "10px 12px", fontSize: "var(--fs-sm)", lineHeight: 1.85, fontFamily: "var(--font-doc)", color: "var(--text-on-paper)", background: "var(--bg-paper)" }}>
            <div style={{ fontFamily: "var(--font-sans)", fontSize: "var(--fs-xs)", color: "var(--text-secondary)", marginBottom: 4, display: "flex", gap: 6, alignItems: "center" }}>
              <Icon.shield /> 将要发出的内容（预览）
              <span style={{ marginLeft: "auto", color: done > 0 ? "var(--status-success-text)" : "var(--text-secondary)", opacity: 0.4 + 0.6 * done }}>{done > 0.5 ? "已替换 3 处 · 机构名称保留" : "正在识别个人信息…"}</span>
            </div>
            任务：{HOME_TASK}。
            <br />
            材料摘录：转让方法定代表人
            <Redact f={f} at={PRIVACY_REDACT[0]} text="张明远" kind="自然人" code="3F9A2C" em={3} />
            （身份证号
            <Redact f={f} at={PRIVACY_REDACT[1]} text="110101199001010000" kind="证件号" code="81D0E4" em={9.5} />
            ）与受让方经办人
            <Redact f={f} at={PRIVACY_REDACT[2]} text="李思源" kind="自然人" code="C27B15" em={3} />
            ，就<Org f={f} at={96}>甲科技有限公司</Org>所持<Org f={f} at={100}>丙数据服务有限公司</Org>股权的转让事宜……
          </div>
          <ul className="muted" style={{ margin: "10px 0 0", paddingLeft: 18, fontSize: "var(--fs-xs)" }}>
            <li>原件留在这台电脑上，只读、不修改</li>
            <li>单任务上限 60 点 · 预计 20 点</li>
          </ul>
          <div className="modal-actions">
            <span className="btn-ghost">返回修改</span>
            <span className="btn-primary" style={{ transform: `scale(${1 - startPressed * 0.08})`, display: "inline-block" }}>开始</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export function S06Privacy() {
  const f = useCurrentFrame();
  const press = f >= PRIVACY_CLICK - 3 && f <= PRIVACY_CLICK + 5 ? 1 - Math.abs(f - PRIVACY_CLICK) / 5 : 0;
  return (
    <AbsoluteFill>
      <StudioBackdrop />
      <ProductStage cam={CAM}>
        <HomeWindow frame={300} text={HOME_TASK} caret={false} chips={2} sendReady sendPressed={0} />
        <ConfirmModal f={f} appear={2} startPressed={press} />
        <Cursor keys={[{ f: 140, x: 860, y: 720 }, { f: 172, x: 961, y: 556 }, { f: 192, x: 961, y: 556 }]} clicks={[PRIVACY_CLICK]} show={[146, 200]} />
      </ProductStage>
      <Headline at={124} x={130} y={380} width={560} size={64} title={<>发出之前，<br />当事人信息<br />先换成代号。</>} sub="材料在本机处理，每一次外发都留有记录。" />
    </AbsoluteFill>
  );
}
