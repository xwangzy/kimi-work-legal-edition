/**
 * S10 · 三条业务线，一个工作空间：诉讼仲裁（事实时间线、金额测算）、非诉（审合同）、企业法务（看板与期限）
 * 四个成果窗口随节拍点亮，随后汇入同一个首页，业务线标签随节拍切换。
 * 案例数据均为虚构示例。
 */
import type { CSSProperties, ReactNode } from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { BEAT } from "../timeline";
import { UNIFY_MERGE } from "../cues.ts";
import { easeInOut, lerp, map, prog, spr } from "../lib/anim";
import { AppWindow, FONT_UI, Headline, ProductStage, StudioBackdrop, type CamKey } from "../ui/film";
import { Icon } from "../ui/Icons";
import { CARDS, Composer, ContractPaper, HomeMain, RiskCard, Shell, Sidebar, type Line } from "../ui/product";

const MW = 960;
const MH = 600;

function Mini({ title, sub, children }: { title: string; sub: string; children: ReactNode }) {
  return (
    <AppWindow w={MW} h={MH}>
      <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "var(--bg-sidebar)" }}>
        <div style={{ height: 48, display: "flex", alignItems: "center", gap: 8, padding: "0 18px 0 90px", borderBottom: "1px solid var(--border-subtle)", background: "var(--bg-main)", fontSize: "var(--fs-sm)" }}>
          <span style={{ color: "var(--text-label)", display: "inline-flex" }}><Icon.file /></span>
          <b style={{ fontWeight: 600 }}>{title}</b>
          <span className="tag tag-gray">草稿</span>
          <span className="muted" style={{ marginLeft: "auto" }}>{sub}</span>
        </div>
        <div style={{ flex: 1, padding: 18, overflow: "hidden" }}>{children}</div>
      </div>
    </AppWindow>
  );
}

function Sheet({ head, rows, widths }: { head: string[]; rows: string[][]; widths?: string }) {
  return (
    <table className="data" style={{ width: "100%", background: "var(--bg-surface)", borderRadius: "var(--r-sm)", fontSize: "var(--fs-sm)", tableLayout: "fixed" }}>
      {widths && (
        <colgroup>
          {widths.split(" ").map((w, i) => (
            <col key={i} style={{ width: w }} />
          ))}
        </colgroup>
      )}
      <thead>
        <tr>{head.map((h) => <th key={h} style={{ textAlign: "left" }}>{h}</th>)}</tr>
      </thead>
      <tbody>
        {rows.map((r, i) => (
          <tr key={i}>{r.map((c, j) => <td key={j} style={{ fontWeight: i === rows.length - 1 && r[0] === "合计" ? 600 : 400 }}>{c}</td>)}</tr>
        ))}
      </tbody>
    </table>
  );
}

const TIMELINE = (
  <Mini title="事实时间线.xlsx" sub="丁建设工程款纠纷（原告）">
    <Sheet
      widths="18% 58% 24%"
      head={["日期", "事实", "证据"]}
      rows={[
        ["2024-05-10", "签订《建设工程施工合同》", "证据 1 · 第 3 页"],
        ["2025-01-20", "工程竣工验收合格", "证据 4 · 第 1 页"],
        ["2025-03-01", "发包人确认结算价 1,286 万元", "证据 6 · 第 2 页"],
        ["2025-06-30", "付款期限届满，尚欠 412 万元", "证据 7 · 第 5 页"],
        ["2025-09-12", "发出催款函，对方签收", "证据 9 · 第 1 页"],
        ["2025-10-08", "对方回函确认欠款，请求延期", "证据 10 · 第 2 页"],
      ]}
    />
    <p className="muted" style={{ marginTop: 10 }}>每条事实可回链到证据页码 · 扫描件在本机 OCR</p>
  </Mini>
);

const AMOUNT = (
  <Mini title="计算明细.xlsx" sub="丁建设工程款纠纷（原告）">
    <Sheet
      widths="9% 37% 18% 16% 20%"
      head={["分段", "起止日", "本金（元）", "利率", "金额（元）"]}
      rows={[
        ["1", "2025-07-01 — 2025-12-31", "4,120,000", "LPR（示例）", "62,307.95"],
        ["2", "2026-01-01 — 2026-06-30", "4,120,000", "LPR（示例）", "61,291.51"],
        ["3", "2026-07-01 — 2026-09-30", "4,120,000", "LPR（示例）", "31,159.45"],
        ["合计", "", "", "", "154,758.91"],
      ]}
    />
    <p className="muted" style={{ marginTop: 10 }}>分段、公式与起止日逐行列明，可直接复核</p>
  </Mini>
);

const CONTRACT = (
  <AppWindow w={MW} h={MH}>
    <div className="wb" style={{ height: "100%" }}>
      <div className="wb-body" style={{ height: "100%" }}>
        <ContractPaper revealRev={{ c1: 1, c2: 1 }} style={{ overflow: "hidden", paddingTop: 44, fontSize: 15 }} />
        <section className="wb-cards" style={{ overflow: "hidden", paddingTop: 44 }}>
          {CARDS.map((c, i) => (
            <RiskCard key={c.id} c={c} open={false} status={i < 2 ? "accepted" : "rejected"} />
          ))}
        </section>
      </div>
    </div>
  </AppWindow>
);

function Widget({ title, children, style }: { title: string; children: ReactNode; style?: CSSProperties }) {
  return (
    <div className="panel" style={{ padding: "12px 14px", ...style }}>
      <div className="muted" style={{ marginBottom: 6 }}>{title}</div>
      {children}
    </div>
  );
}

const BOARD = (
  <Mini title="看板" sub="戊集团法务部">
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, fontSize: "var(--fs-sm)" }}>
      <Widget title="待复核 / 签发">
        <div style={{ fontSize: 28, fontWeight: 600 }}>3 <span className="muted">份</span></div>
      </Widget>
      <Widget title="进行中的事项">
        <div style={{ fontSize: 28, fontWeight: 600 }}>6 <span className="muted">项</span></div>
      </Widget>
      <Widget title="期限">
        {[
          ["10-21", "戊集团 · 供货合同续签届满"],
          ["10-28", "己公司 · 仲裁答辩期届满"],
          ["11-05", "年度合规报告提交"],
        ].map(([d, t]) => (
          <div key={d} style={{ display: "flex", gap: 8, padding: "2px 0" }}>
            <span className="pill pill-orange">{d}</span>
            <span>{t}</span>
          </div>
        ))}
      </Widget>
      <Widget title="联网记录">
        {[
          ["已发出", "18"],
          ["已拦下（没有发出）", "6"],
          ["需要核对", "0"],
        ].map(([k, v]) => (
          <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "2px 0" }}>
            <span>{k}</span>
            <b>{v}</b>
          </div>
        ))}
      </Widget>
    </div>
  </Mini>
);

const TILES: { node: ReactNode; label: string; line: number; x: number; y: number; ry: number }[] = [
  { node: TIMELINE, label: "诉讼仲裁 · 整理案卷", line: 0, x: -380, y: -140, ry: 10 },
  { node: AMOUNT, label: "诉讼仲裁 · 金额测算", line: 0, x: 380, y: -140, ry: -10 },
  { node: CONTRACT, label: "非诉 · 审合同", line: 1, x: -380, y: 268, ry: 10 },
  { node: BOARD, label: "企业法务 · 看板与期限", line: 2, x: 380, y: 268, ry: -10 },
];

const LINE_AT = [12, 12 + BEAT * 2, 12 + BEAT * 4];
const MERGE = UNIFY_MERGE;

const CAM: CamKey[] = [
  { f: 0, fx: 720, fy: 450, s: 0.3, rx: 0, ry: 0, ox: 0, oy: 40 },
  { f: MERGE, fx: 720, fy: 450, s: 0.3, rx: 0, ry: 0, ox: 0, oy: 40 },
  { f: MERGE + 44, fx: 720, fy: 450, s: 0.8, rx: 0, ry: 0, ox: 0, oy: 70 },
  { f: 256, fx: 720, fy: 460, s: 0.86, rx: 0, ry: 0, ox: 0, oy: 70 },
];

export function S10Unify() {
  const f = useCurrentFrame();
  const merge = prog(f, MERGE, 40, easeInOut);
  const lit = f < LINE_AT[1] ? 0 : f < LINE_AT[2] ? 1 : 2;
  // 汇入后，首页业务线标签随节拍切换
  const lines: Line[] = ["litigation", "transactional", "inhouse"];
  const cycleStart = MERGE + 44;
  const li = f < cycleStart ? 0 : Math.min(2, Math.floor((f - cycleStart) / (BEAT * 2)));
  const local = f < cycleStart ? 99 : f - cycleStart - li * BEAT * 2;
  const card = (i: number): CSSProperties => {
    const p = spr(local, i * 1.5, 200, 22);
    return f < cycleStart ? {} : { opacity: Math.min(1, p * 1.4), transform: `translateY(${(1 - p) * 10}px)` };
  };
  return (
    <AbsoluteFill>
      <StudioBackdrop />
      {/* 四个成果窗口 */}
      <AbsoluteFill style={{ perspective: 2200, opacity: 1 - prog(f, MERGE + 6, 16) }}>
        {TILES.map((t, i) => {
          const p = spr(f, i * 2, 150, 22);
          const on = f >= LINE_AT[t.line];
          const active = t.line === lit && f < MERGE;
          const s = 0.6;
          const x = lerp(t.x, 0, merge);
          const y = lerp(t.y, 20, merge);
          return (
            <div key={i} style={{ position: "absolute", left: 960 - MW / 2, top: 540 - MH / 2, width: MW, height: MH, transform: `translate3d(${x}px, ${y + (1 - p) * 60}px, ${active ? 40 : 0}px) rotateY(${lerp(t.ry, 0, merge)}deg) scale(${s * lerp(1, 0.8, merge)})`, opacity: Math.min(1, p * 1.4), filter: `saturate(${on ? 1 : 0.2}) brightness(${active || f >= MERGE ? 1 : on ? 0.97 : 0.92})` }}>
              <div style={{ position: "absolute", left: 0, top: -64, fontFamily: FONT_UI, fontSize: 30, fontWeight: 600, color: active ? "#0e1219" : "#8a867f" }}>{t.label}</div>
              {t.node}
            </div>
          );
        })}
      </AbsoluteFill>
      {/* 汇入后的首页 */}
      <div style={{ position: "absolute", inset: 0, opacity: prog(f, MERGE + 4, 18) }}>
        <ProductStage cam={CAM}>
          <AppWindow>
            <Shell sidebar={<Sidebar active="home" />}>
              <HomeMain line={lines[li]} cardStyle={card} composer={<Composer text="" placeholder="描述要处理的法律工作。例如：审查这份股权转让协议，我方为受让方" matterChip="未选择事项" />} />
            </Shell>
          </AppWindow>
        </ProductStage>
      </div>
      {/* 标题：三条业务线随节拍出现，汇入后换成“一个工作空间” */}
      <div style={{ position: "absolute", top: 48, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 36, fontFamily: FONT_UI, fontSize: 40, fontWeight: 600, opacity: 1 - prog(f, MERGE, 16) }}>
        {["诉讼仲裁", "非诉交易", "企业法务"].map((w, i) => {
          const p = prog(f, LINE_AT[i], 16);
          return (
            <span key={w} style={{ opacity: p * (lit === i ? 1 : 0.38), transform: `translateY(${(1 - p) * 16}px)`, filter: `blur(${(1 - p) * 6}px)`, color: "#0e1219" }}>
              {w}
            </span>
          );
        })}
      </div>
      <Headline at={MERGE + 30} x={960} y={map(f, [MERGE + 30, 256], [40, 34])} align="center" width={1400} size={52} title="一个工作空间。" sub="按律师的业务线组织：方法、材料与交付件，都在同一处。" subSize={24} />
    </AbsoluteFill>
  );
}
