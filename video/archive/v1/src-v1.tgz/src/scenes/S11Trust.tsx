/**
 * S11 · 可信：三项与产品实现一一对应的安全边界——
 * 本机执行与按事项加密、数据去向逐条记录、签发须律师确认并带设备签名。
 */
import type { ReactNode } from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { prog, spr } from "../lib/anim";
import { FONT_DISPLAY, FONT_UI, Headline, INK, StudioBackdrop } from "../ui/film";
import { Icon } from "../ui/Icons";

function Column({ at, out, proof, title, desc }: { at: number; out: number; proof: ReactNode; title: string; desc: string }) {
  const f = useCurrentFrame();
  const p = spr(f, at, 120, 24);
  const o = 1 - prog(f, out, 14);
  return (
    <div style={{ width: 500, opacity: Math.min(1, p * 1.4) * o, transform: `translateY(${(1 - p) * 40}px)` }}>
      <div style={{ height: 250, borderRadius: 18, background: "#fff", boxShadow: "0 0 0 1px rgba(14,18,25,0.06), 0 30px 60px -30px rgba(14,18,25,0.25)", padding: 26, display: "flex", flexDirection: "column", justifyContent: "center", overflow: "hidden" }}>
        {proof}
      </div>
      <div style={{ fontFamily: FONT_DISPLAY, fontSize: 36, fontWeight: 600, color: INK, marginTop: 30, opacity: prog(f, at + 6, 18) }}>{title}</div>
      <div style={{ fontFamily: FONT_UI, fontSize: 21, lineHeight: 1.6, color: "#6b6862", marginTop: 10, opacity: prog(f, at + 12, 18) }}>{desc}</div>
    </div>
  );
}

export function S11Trust() {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <StudioBackdrop />
      <Headline at={2} out={176} x={960} y={190} align="center" width={1500} size={56} title="为律所的保密义务而设计。" />
      <div style={{ position: "absolute", top: 380, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 70 }}>
        <Column
          at={20}
          out={178}
          title="在律所电脑上执行"
          desc="事项、材料与成果留在本机，按事项加密保存；原件只读，结果都是草稿。"
          proof={
            <div style={{ fontSize: 17 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12, fontSize: 24, fontWeight: 500 }}>
                <span className="dot dot-ok" style={{ width: 14, height: 14, flexBasis: 14, marginTop: 0, boxShadow: "0 0 0 6px rgba(18,183,106,0.14)" }} />
                本机运行 · 防护正常
              </div>
              <div className="muted" style={{ marginTop: 18, fontSize: 16, lineHeight: 1.8 }}>
                在这台电脑上处理 · 原件不会被修改
                <br />
                <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}><Icon.lock /> 材料按事项密钥加密</span>
              </div>
            </div>
          }
        />
        <Column
          at={20 + 32}
          out={180}
          title="每一次外发，都有去向"
          desc="发给谁、发了什么、替换了哪些个人信息，逐条记入数据去向。"
          proof={
            <table className="data" style={{ width: "100%", fontSize: 14 }}>
              <thead>
                <tr><th style={{ textAlign: "left" }}>目的地</th><th style={{ textAlign: "left" }}>内容</th><th style={{ textAlign: "left" }}>结果</th></tr>
              </thead>
              <tbody>
                <tr><td>Kimi 模型<br /><span className="muted">经中软法律模型网关</span></td><td>任务说明 + 3 段摘录<br /><span className="muted">替换个人信息 3 处</span></td><td><span className="pill pill-green">已发出</span></td></tr>
                <tr><td>联网检索</td><td>含当事人姓名的查询</td><td><span className="pill pill-orange">已拦下</span></td></tr>
              </tbody>
            </table>
          }
        />
        <Column
          at={20 + 64}
          out={182}
          title="签发，由律师确认"
          desc="无法核实的引用不能签发；签发记录带设备签名，可离线核验。"
          proof={
            <div style={{ fontSize: 16 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 18, fontWeight: 500 }}>
                <span style={{ color: "var(--text-label)", display: "inline-flex" }}><Icon.file /></span> 审查意见书（签发版）.docx
              </div>
              <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
                <span className="pill pill-green">已签发</span>
                <span className="pill pill-blue">设备签名</span>
                <span className="pill pill-gray">引用全部已核</span>
              </div>
              <div className="mono muted" style={{ marginTop: 16, fontSize: 13 }}>sha256 · 3f9a2c81d0e4…c27b15</div>
            </div>
          }
        />
      </div>
    </AbsoluteFill>
  );
}
