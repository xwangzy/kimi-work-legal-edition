/**
 * S9 · AI 提出意见，律师作出判断：审查工作台（合同纸面 | 风险卡）。
 * 律师逐项接受 / 不采纳，合同出现修订痕迹；随后一键生成带修订痕迹与批注的 Word 修订稿（原件不改动）。
 */
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { easeInOut, map, prog, spr } from "../lib/anim";
import { AppWindow, Cursor, FONT_DOC, FONT_UI, Headline, ProductStage, StudioBackdrop, type CamKey } from "../ui/film";
import { CARDS, ContractPaper, RiskCard, Shell, Sidebar, type CardStatus } from "../ui/product";

import { C1_ACCEPT, C2_ACCEPT, C3_REJECT, REDLINE_CLICK } from "../cues.ts";

const CAM: CamKey[] = [
  { f: 0, fx: 720, fy: 450, s: 0.86, rx: 2, ry: -13, ox: 460, oy: 20 },
  { f: 60, fx: 720, fy: 450, s: 0.9, rx: 2, ry: -11, ox: 450, oy: 20 },
  { f: 96, fx: 930, fy: 360, s: 1.5, rx: 0, ry: -2, ox: 0, oy: 0 },
  { f: 150, fx: 930, fy: 400, s: 1.5, rx: 0, ry: -2, ox: 0, oy: 0 },
  { f: 200, fx: 940, fy: 450, s: 1.46, rx: 0, ry: -2, ox: 0, oy: 0 },
  { f: 236, fx: 900, fy: 420, s: 1.36, rx: 0, ry: 0, ox: 0, oy: 0 },
  { f: 262, fx: 1000, fy: 230, s: 1.3, rx: 0, ry: 0, ox: 0, oy: 0 },
  { f: 320, fx: 720, fy: 450, s: 0.62, rx: 4, ry: 18, ox: 430, oy: 40 },
];

function useReviewState(f: number) {
  const status = (id: string): CardStatus => {
    if (id === "c1" && f >= C1_ACCEPT + 2) return "accepted";
    if (id === "c2" && f >= C2_ACCEPT + 2) return "accepted";
    if (id === "c3" && f >= C3_REJECT + 2) return "rejected";
    return "proposed";
  };
  const open = f < C1_ACCEPT + 14 ? "c1" : f < C2_ACCEPT + 12 ? "c2" : f < C3_REJECT + 10 ? "c3" : "";
  const accepted = (["c1", "c2", "c3"] as const).filter((x) => status(x) === "accepted").length;
  const decided = (["c1", "c2", "c3"] as const).filter((x) => status(x) !== "proposed").length;
  return { status, open, accepted, decided };
}

function ReviewWorkbench({ f }: { f: number }) {
  const { status, open, accepted, decided } = useReviewState(f);
  const pressed = f >= REDLINE_CLICK - 3 && f <= REDLINE_CLICK + 5 ? 1 - Math.abs(f - REDLINE_CLICK) / 5 : 0;
  const done = f >= REDLINE_CLICK + 4;
  const bannerP = spr(f, REDLINE_CLICK + 4, 170, 22);
  const press = (at: number) => (f >= at - 3 && f <= at + 5 ? 1 - Math.abs(f - at) / 5 : 0);
  return (
    <div className="wb">
      <div className="wb-head" style={{ paddingTop: 22 }}>
        <div className="wb-title">
          <span className="btn-link">← 返回任务</span>
          <h1 className="page-title">审查工作台 · 股权转让协议.docx</h1>
          <div className="wb-progress">
            已处理 {decided}/3{status("c1") === "proposed" && <span className="sev-text-high"> · 1 项重大风险待处理</span>}
          </div>
        </div>
        <div className="wb-head-actions" style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
          <span className={decided === 3 ? "btn-primary" : "btn-ghost"} style={{ display: "inline-block", opacity: accepted === 0 ? 0.5 : 1, transform: `scale(${1 - pressed * 0.07})` }}>
            生成修订稿{accepted > 0 ? `（${accepted} 项）` : ""}
          </span>
          <div className="wb-why muted" style={{ fontSize: "var(--fs-xs)" }}>
            {accepted === 0 ? "先接受或修改后接受至少一项（还有 3 项未处理）" : decided < 3 ? `还有 ${3 - decided} 项未处理 · 现在生成也可以，未处理的不写入修订稿` : "已全部处理 · 不采纳的意见不写入修订稿"}
          </div>
        </div>
      </div>
      {done && (
        <div className="banner banner-green" style={{ opacity: Math.min(1, bannerP * 1.5), transform: `translateY(${(1 - bannerP) * -8}px)` }}>
          已生成修订稿：股权转让协议（修订稿）.docx · 2 处修订、2 条批注 · 原件未改动
          <div className="banner-actions">
            <span className="btn-primary">查看修订稿</span>
          </div>
        </div>
      )}
      <div className="wb-body">
        <ContractPaper
          active={open || undefined}
          revealRev={{ c1: prog(f, C1_ACCEPT + 4, 30, easeInOut), c2: prog(f, C2_ACCEPT + 4, 28, easeInOut) }}
          rejected={{ c3: status("c3") === "rejected" }}
          style={{ overflow: "hidden" }}
        />
        <section className="wb-cards" style={{ overflow: "hidden" }}>
          <div className="wb-filters">
            <span className="chip active">全部 3</span>
            <span className="chip">待处理 {3 - decided}</span>
            <span className="chip">已接受 {accepted}</span>
            <span className="chip">不采纳 {status("c3") === "rejected" ? 1 : 0}</span>
          </div>
          <div className="wb-keys muted">快捷键：J / K 切换 · A 接受 · E 修改 · N 不采纳</div>
          {CARDS.map((c) => (
            <RiskCard key={c.id} c={c} open={open === c.id} status={status(c.id)} hover={press(c.id === "c1" ? C1_ACCEPT : C2_ACCEPT)} />
          ))}
        </section>
      </div>
    </div>
  );
}

/** 飞出的 Word 修订稿：修订痕迹 + 页边批注。 */
function RedlineDoc({ f }: { f: number }) {
  const p = spr(f, REDLINE_CLICK + 10, 90, 20);
  if (f < REDLINE_CLICK + 8) return null;
  const del = { color: "#c0392b", textDecoration: "line-through" } as const;
  const ins = { color: "#1f5fbf", textDecoration: "underline", textUnderlineOffset: 3 } as const;
  return (
    <div
      style={{
        position: "absolute",
        left: map(p, [0, 1], [900, 150], easeInOut),
        top: map(p, [0, 1], [380, 220], easeInOut),
        width: 760,
        transform: `perspective(1800px) rotateY(${map(p, [0, 1], [0, 12])}deg) rotateZ(${map(p, [0, 1], [0, -2])}deg) scale(${0.35 + 0.65 * p})`,
        transformOrigin: "50% 50%",
        opacity: Math.min(1, p * 2),
      }}
    >
      <div style={{ fontFamily: FONT_UI, fontSize: 15, color: "#fff", background: "#2b579a", borderRadius: "10px 10px 0 0", padding: "9px 16px", display: "flex", gap: 10, alignItems: "center" }}>
        <span style={{ fontWeight: 700, background: "#fff", color: "#2b579a", borderRadius: 3, padding: "0 5px", fontSize: 13 }}>W</span>
        股权转让协议（修订稿）.docx
        <span style={{ marginLeft: "auto", opacity: 0.8, fontSize: 13 }}>修订 2 · 批注 2</span>
      </div>
      <div style={{ display: "flex", background: "#fff", borderRadius: "0 0 10px 10px", boxShadow: "0 40px 90px -30px rgba(14,18,25,0.45), 0 0 0 1px rgba(14,18,25,0.06)" }}>
        <div style={{ flex: 1, padding: "26px 28px", fontFamily: FONT_DOC, fontSize: 16, lineHeight: 2, color: "#1f1d1a" }}>
          <p style={{ margin: "0 0 4px", fontWeight: 600 }}>第二条　转让价款与支付</p>
          <p style={{ margin: "0 0 10px" }}>
            2.2　<span style={del}>受让方应于协议签署后五日内一次性支付全部价款</span>
            <span style={ins}>受让方应于目标股权变更登记完成后五个工作日内支付全部价款</span>。
          </p>
          <p style={{ margin: "0 0 4px", fontWeight: 600 }}>第七条　违约责任</p>
          <p style={{ margin: 0 }}>
            7.1　受让方逾期付款的，<span style={del}>每日按应付未付金额的千分之五支付违约金</span>
            <span style={ins}>每日按应付未付金额的万分之五支付违约金，累计不超过转让价款的百分之五</span>。
          </p>
        </div>
        <div style={{ width: 190, padding: "26px 14px 20px 0", display: "flex", flexDirection: "column", gap: 14, fontFamily: FONT_UI }}>
          {["付款以变更登记完成为前提，避免先付款后追讨。", "违约金调整至合理区间，并设累计上限。"].map((t, i) => (
            <div key={i} style={{ fontSize: 12, lineHeight: 1.6, color: "#3b3b3b", background: "#fdf3d8", borderLeft: "3px solid #e2b33a", borderRadius: 4, padding: "6px 8px", opacity: prog(f, REDLINE_CLICK + 24 + i * 8, 12) }}>
              <b style={{ display: "block", fontSize: 11, color: "#7a5b0b" }}>批注 {i + 1}</b>
              {t}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function S09Review() {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <StudioBackdrop />
      <ProductStage cam={CAM}>
        <AppWindow>
          <Shell sidebar={<Sidebar active="matters" activeRecent={0} />}>
            <ReviewWorkbench f={f} />
          </Shell>
        </AppWindow>
        <Cursor
          keys={[
            { f: 70, x: 1150, y: 640 },
            { f: 106, x: 971, y: 549 },
            { f: 150, x: 1010, y: 520 },
            { f: 186, x: 971, y: 556 },
            { f: 204, x: 1100, y: 600 },
            { f: 220, x: 1160, y: 528 },
            { f: 250, x: 1336, y: 50 },
            { f: 280, x: 1336, y: 50 },
          ]}
          clicks={[C1_ACCEPT, C2_ACCEPT, C3_REJECT, REDLINE_CLICK]}
          show={[76, 272]}
        />
      </ProductStage>
      <Headline at={8} out={66} x={130} y={380} width={560} size={72} title={<>AI 提出意见，</>} />
      <Headline at={26} out={68} x={130} y={468} width={560} size={72} title={<>律师作出判断。</>} sub="接受、修改或不采纳——每一项都由你决定。" />
      <RedlineDoc f={f} />
      <Headline at={278} x={150} y={680} width={760} size={48} title="修订稿，一键生成。" sub="带修订痕迹与批注的 Word 文件，原件不改动。" subSize={22} />
    </AbsoluteFill>
  );
}
