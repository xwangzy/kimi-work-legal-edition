/** S5 · 一句话，交代任务：首页输入框打字 → 附上合同 → 发送。 */
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { spr, typed } from "../lib/anim";
import { AppWindow, Cursor, Headline, ProductStage, StudioBackdrop, type CamKey } from "../ui/film";
import { Icon } from "../ui/Icons";
import { Composer, HomeMain, Shell, Sidebar } from "../ui/product";

import { HOME_CLICK, HOME_TASK, HOME_TYPE_AT, HOME_TYPE_CPS } from "../cues.ts";
export { HOME_TASK };
/** 首页终止镜头（S6 从这里接续）。 */
export const HOME_END_CAM: CamKey = { f: 0, fx: 868, fy: 300, s: 1.18, rx: 0, ry: 0, ox: 0, oy: 40 };

const CAM: CamKey[] = [
  { f: 0, fx: 720, fy: 450, s: 0.84, rx: 0, ry: 0, ox: 0, oy: 20 },
  { f: 40, fx: 720, fy: 420, s: 0.9, rx: 3, ry: -14, ox: 430, oy: 30 },
  { f: 128, fx: 760, fy: 400, s: 0.94, rx: 2, ry: -12, ox: 420, oy: 30 },
  { f: 170, fx: 868, fy: 300, s: 1.18, rx: 0, ry: 0, ox: 0, oy: 40 },
  { ...HOME_END_CAM, f: 255 },
];

export function HomeWindow({ frame, text, caret, chips, sendReady, sendPressed }: { frame: number; text: string; caret: boolean; chips: number; sendReady: boolean; sendPressed: number }) {
  const chipStyle = (at: number) => {
    const p = spr(frame, at, 170, 20);
    return { opacity: Math.min(1, p * 1.5), transform: `translateY(${(1 - p) * 8}px) scale(${0.9 + p * 0.1})`, display: "inline-flex" } as const;
  };
  return (
    <AppWindow>
      <Shell sidebar={<Sidebar active="home" />}>
        <HomeMain
          line="transactional"
          composer={
            <Composer
              text={text}
              caret={caret}
              caretOn={Math.floor(frame / 8) % 2 === 0 || caret}
              focus
              placeholder="描述要处理的法律工作。例如：审查这份股权转让协议，我方为受让方"
              matterChip="甲公司股权转让（受让方）"
              sendReady={sendReady}
              sendPressed={sendPressed}
              chips={
                chips > 0 ? (
                  <>
                    <span className="chip chip-soft" style={chipStyle(148)}><Icon.file /> 股权转让协议.docx</span>
                    {chips > 1 && <span className="chip chip-soft" style={chipStyle(160)}><Icon.slash /> 审合同</span>}
                  </>
                ) : undefined
              }
            />
          }
        />
      </Shell>
    </AppWindow>
  );
}

export function S05Home() {
  const f = useCurrentFrame();
  const [text, typing] = typed(HOME_TASK, f, HOME_TYPE_AT, HOME_TYPE_CPS);
  const chips = f >= 160 ? 2 : f >= 148 ? 1 : 0;
  const press = f >= HOME_CLICK - 3 && f <= HOME_CLICK + 5 ? 1 - Math.abs(f - HOME_CLICK) / 5 : 0;
  return (
    <AbsoluteFill>
      <StudioBackdrop />
      <ProductStage cam={CAM}>
        <HomeWindow frame={f} text={text} caret={typing || (f > HOME_TYPE_AT - 10 && f < HOME_CLICK)} chips={chips} sendReady={text.length > 0} sendPressed={press} />
        <Cursor
          keys={[
            { f: 150, x: 1010, y: 520 },
            { f: 200, x: 1229, y: 347 },
            { f: 255, x: 1229, y: 347 },
          ]}
          clicks={[HOME_CLICK]}
          show={[160, 260]}
        />
      </ProductStage>
      <Headline at={30} out={132} x={130} y={400} title={<>一句话，<br />交代任务。</>} sub="描述要做的事，附上材料。方法、步骤与交付件，由助手来组织。" width={520} size={72} />
    </AbsoluteFill>
  );
}
