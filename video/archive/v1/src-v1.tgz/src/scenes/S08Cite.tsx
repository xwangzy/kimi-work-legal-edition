/**
 * S8 · 每一条引用，都核对来源与版本：执行页“引用”标签。
 * 状态与文案对应产品 CITE_STATE_LABELS（来源已核 / 版本已核 / 已拦截）；无法核实的引用不得进入签发版（review.approve 409）。
 */
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { prog, spr } from "../lib/anim";
import { Cursor, Headline, ProductStage, Scrim, StudioBackdrop, type CamKey } from "../ui/film";
import { RunWindow } from "./S07Run";

import { CITE_CLICK } from "../cues.ts";

const CAM: CamKey[] = [
  { f: 0, fx: 1120, fy: 400, s: 1.36, rx: 0, ry: 0, ox: 0, oy: 0 },
  { f: 22, fx: 1120, fy: 400, s: 1.36, rx: 0, ry: 0, ox: 0, oy: 0 },
  { f: 70, fx: 1120, fy: 380, s: 1.3, rx: 1, ry: -6, ox: 360, oy: 10 },
  { f: 192, fx: 1120, fy: 384, s: 1.34, rx: 1, ry: -5, ox: 350, oy: 10 },
];

const VERDICTS = [
  { raw: "《民法典》第五百二十六条", state: "source_verified", label: "来源已核", law: "中华人民共和国民法典〔现行有效〕", note: "先履行抗辩权：对方未先办理变更登记的，受让方可拒绝付款。", at: 24, ok: 40 },
  { raw: "《民法典》第五百八十五条", state: "version_verified", label: "版本已核", law: "中华人民共和国民法典〔现行有效〕", note: "按协议签署时点（2026 年 3 月）取版本；违约金过分高于损失的，可请求适当减少。", at: 40, ok: 56 },
  { raw: "（2023）沪01民终×××号", state: "intercepted", label: "已拦截", law: "未匹配法源", note: "本机案例库无法核实该案号。", suggest: "建议：核实来源后再引用；复核确认前不得作为依据。", at: 56, ok: 80 },
];

function Verdicts({ f }: { f: number }) {
  const banner = spr(f, 84, 170, 22);
  return (
    <div>
      <div className="muted" style={{ fontSize: "var(--fs-xs)", marginBottom: 10 }}>本机法规库 · 最后更新 2026-10-15 · 离线核验，不联网</div>
      {f >= 84 && (
        <div className="banner banner-red" style={{ opacity: Math.min(1, banner * 1.5), transform: `translateY(${(1 - banner) * -8}px)`, marginBottom: 10 }}>
          本次拦截 1 条无法核实的引用（不静默删除，复核确认前不得作为依据）。
        </div>
      )}
      {VERDICTS.map((v) => {
        if (f < v.at) return null;
        const p = spr(f, v.at, 170, 22);
        const resolved = f >= v.ok;
        const r = prog(f, v.ok, 8);
        return (
          <div key={v.raw} className="verdict" style={{ opacity: Math.min(1, p * 1.5), transform: `translateY(${(1 - p) * 12}px)`, borderColor: resolved && v.state === "intercepted" ? "var(--status-danger-border)" : undefined }}>
            <div>
              <span className="raw" style={{ fontFamily: "var(--font-sans)", fontSize: "var(--fs-base)", fontWeight: 500 }}>{v.raw}</span>{" "}
              {resolved ? (
                <span className={`cite-state cite-${v.state}`} style={{ display: "inline-block", transform: `scale(${0.85 + 0.15 * r})`, opacity: r }}>{v.label}</span>
              ) : (
                <span className="cite-state" style={{ color: "var(--text-secondary)", background: "var(--bg-hover)" }}>
                  <Spinner f={f} /> 核验中
                </span>
              )}
            </div>
            {resolved && (
              <div style={{ opacity: r }}>
                <div className="row">{v.law}</div>
                <div className="row">{v.note}</div>
                {v.suggest && <div className="row" style={{ color: "var(--status-danger-text)" }}>{v.suggest}</div>}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function Spinner({ f }: { f: number }) {
  return (
    <svg width="10" height="10" viewBox="0 0 10 10" style={{ verticalAlign: "-1px", transform: `rotate(${f * 18}deg)` }}>
      <circle cx="5" cy="5" r="3.8" fill="none" stroke="currentColor" strokeOpacity="0.25" strokeWidth="1.4" />
      <path d="M5 1.2 A3.8 3.8 0 0 1 8.8 5" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

export function S08Cite() {
  const f = useCurrentFrame();
  const runF = 256 + f; // 接续 S7 的运行进度
  const tab = f >= CITE_CLICK + 2 ? "引用" : "成果";
  return (
    <AbsoluteFill>
      <StudioBackdrop />
      <ProductStage cam={CAM}>
        <RunWindow f={runF} tab={tab} rightChildren={tab === "引用" ? <Verdicts f={f} /> : undefined} />
        <Cursor keys={[{ f: 0, x: 1150, y: 300 }, { f: 13, x: 1078, y: 30 }, { f: 40, x: 1100, y: 120 }]} clicks={[CITE_CLICK]} show={[0, 34]} />
      </ProductStage>
      <Scrim opacity={prog(f, 40, 30)} to={50} />
      <Headline at={58} out={180} x={130} y={400} width={620} size={64} title={<>每一条引用，<br />都核对来源与版本。</>} sub="无法核实的，不会进入签发版。" />
    </AbsoluteFill>
  );
}
