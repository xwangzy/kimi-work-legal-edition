/** S7 · 先出计划，再动手：任务执行三栏（材料 | 进度 | 预览），计划确认后步骤随节拍推进。 */
import type { CSSProperties } from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { prog, spr } from "../lib/anim";
import { AppWindow, Cursor, Headline, ProductStage, StudioBackdrop, type CamKey } from "../ui/film";
import { Icon } from "../ui/Icons";
import { CARDS, RunLeft, RunTabs, Shell, Sidebar, Timeline, type Step } from "../ui/product";
import { HOME_TASK } from "./S05Home";

import { RUN_CLICK } from "../cues.ts";

const CAM: CamKey[] = [
  { f: 0, fx: 720, fy: 450, s: 0.86, rx: 2, ry: -13, ox: 460, oy: 20 },
  { f: 84, fx: 700, fy: 440, s: 0.92, rx: 2, ry: -11, ox: 440, oy: 20 },
  { f: 112, fx: 560, fy: 420, s: 1.42, rx: 0, ry: -2, ox: 0, oy: 0 },
  { f: 168, fx: 600, fy: 440, s: 1.42, rx: 0, ry: -2, ox: 0, oy: 0 },
  { f: 220, fx: 1120, fy: 400, s: 1.36, rx: 0, ry: 0, ox: 0, oy: 0 },
  { f: 256, fx: 1120, fy: 400, s: 1.36, rx: 0, ry: 0, ox: 0, oy: 0 },
];

/** 运行到某帧时的步骤状态（S8 复用其终态）。 */
export function runSteps(f: number): { s: Step; at: number }[] {
  const st = (appear: number, done: number | null): Step["state"] => (done !== null && f >= done ? "done" : f >= appear ? "wait" : "pending");
  return [
    { at: 86, s: { title: "确认工作计划", detail: "你已确认 · 17:02", state: st(86, 86) } },
    { at: 96, s: { title: "读取材料", detail: "股权转让协议.docx · 12 页 · 原件只读", state: st(96, 112) } },
    { at: 112, s: { title: "识别风险条款", detail: f >= 144 ? "发现 3 处：重大 1 · 一般 1 · 提示 1" : "按受让方立场逐条阅读…", state: st(112, 144) } },
    { at: 144, s: { title: "核验法律依据", detail: f >= 176 ? "2 条来源与版本已核 · 1 条无法核实，已拦截" : "对照本机法规库…", state: st(144, 176) } },
    { at: 176, s: { title: "起草审查意见与修订建议", detail: "正在起草…", state: st(176, null) } },
  ];
}

function PlanCard({ f, pressed }: { f: number; pressed: number }) {
  const p = spr(f, 8, 160, 22);
  const collapse = prog(f, RUN_CLICK + 4, 12);
  if (collapse >= 1) return null;
  return (
    <div style={{ opacity: Math.min(1, p * 1.4) * (1 - collapse), transform: `translateY(${(1 - p) * 14}px) scale(${1 - collapse * 0.04})`, transformOrigin: "50% 0", maxHeight: `${(1 - collapse) * 420}px`, overflow: "hidden", marginTop: 10 }}>
      <div className="card-confirm card-plan">
        <div className="cc-head"><Icon.list /> 请确认工作计划</div>
        <div className="cc-plan">
          <ol style={{ margin: "4px 0", paddingLeft: 20, lineHeight: 1.85, fontSize: "var(--fs-sm)" }}>
            <li>通读协议，按受让方立场逐条识别风险</li>
            <li>对照现行法规，核验每一条依据的来源与版本</li>
            <li>逐条给出修改建议与可退让方案</li>
            <li>生成审查意见书，以及带修订痕迹的 Word 修订稿</li>
          </ol>
        </div>
        <div className="cc-actions">
          <span className="btn-primary" style={{ display: "inline-block", transform: `scale(${1 - pressed * 0.07})` }}>按这个计划开始</span>
          <span className="btn-ghost">提修改意见</span>
        </div>
        <div className="cc-foot">计划确认前，助手不会读取材料以外的任何内容。</div>
      </div>
    </div>
  );
}

const DRAFT = [
  "关于《股权转让协议》的审查意见（内部稿）",
  "一、总体评价",
  "协议结构完整，但付款安排与违约责任对受让方明显不利，建议在签署前重点调整第 2.2 条与第 7.1 条。",
  "二、主要风险与修改建议",
  "1. 第 2.2 条：价款在股权变更登记前一次性付清，受让方承担全部交割风险。建议改为变更登记完成后五个工作日内支付。",
  "2. 第 7.1 条：逾期付款违约金按日千分之五计，明显偏高……",
];

export function RightPane({ f, tab = "成果", summaryAt = 150, draftAt = 180, children, style }: { f: number; tab?: string; summaryAt?: number; draftAt?: number; children?: React.ReactNode; style?: CSSProperties }) {
  const sp = (k: number) => {
    const p = spr(f, summaryAt + k * 4, 180, 20);
    return { opacity: Math.min(1, p * 1.5), transform: `translateY(${(1 - p) * 8}px)`, display: "inline-flex" } as const;
  };
  const chars = Math.max(0, Math.floor((f - draftAt) * 2.4));
  let left = chars;
  return (
    <aside className="exec-right" style={style}>
      <RunTabs active={tab} />
      <div className="tab-body" style={{ overflow: "hidden" }}>
        {children ?? (
          <>
            {f >= summaryAt && (
              <div className="review-summary">
                <div className="sev-row" style={{ display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                  <span className="pill pill-red" style={sp(0)}>重大 1</span>
                  <span className="pill pill-orange" style={sp(1)}>一般 1</span>
                  <span className="pill pill-gray" style={sp(2)}>提示 1</span>
                  <span className="muted" style={sp(3)}>已处理 0/3</span>
                </div>
                <ol className="review-top" style={{ margin: "10px 0", paddingLeft: 18, fontSize: "var(--fs-sm)", lineHeight: 1.8 }}>
                  {CARDS.map((c, i) => (
                    <li key={c.id} style={sp(4 + i)}>
                      <span className="rc-ref" style={{ marginRight: 6 }}>{c.ref}</span>
                      {c.issue.slice(0, 22)}…
                    </li>
                  ))}
                </ol>
                <span className="btn-ghost" style={{ ...sp(8), display: "inline-block" }}>打开审查工作台</span>
              </div>
            )}
            {f >= draftAt && (
              <div style={{ marginTop: 16, opacity: prog(f, draftAt, 10) }}>
                <div className="pane-title" style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <Icon.file /> 审查意见书（内部稿）.docx <span className="tag tag-gray">草稿</span>
                </div>
                <div style={{ marginTop: 8, background: "var(--bg-paper)", border: "1px solid var(--paper-border)", borderRadius: "var(--r-sm)", padding: "18px 22px", minHeight: 260, fontFamily: "var(--font-doc)", color: "var(--text-on-paper)", fontSize: 14, lineHeight: 1.85, boxShadow: "var(--shadow-xs)" }}>
                  {DRAFT.map((l, i) => {
                    const n = Math.max(0, Math.min(l.length, left));
                    left -= l.length;
                    if (n <= 0) return null;
                    const head = i === 0;
                    const h2 = l.startsWith("一、") || l.startsWith("二、");
                    return (
                      <p key={i} style={{ margin: head ? "0 0 10px" : "0 0 6px", textAlign: head ? "center" : "left", fontWeight: head || h2 ? 600 : 400, textIndent: head || h2 ? 0 : "2em" }}>
                        {l.slice(0, n)}
                        {n < l.length && <span style={{ display: "inline-block", width: 1.5, height: "1em", background: "var(--accent)", verticalAlign: "-0.15em" }} />}
                      </p>
                    );
                  })}
                </div>
              </div>
            )}
            {f < summaryAt && <p className="muted">任务完成后，生成的文件会出现在这里。</p>}
          </>
        )}
      </div>
    </aside>
  );
}

export function RunWindow({ f, pressed = 0, tab = "成果", rightChildren }: { f: number; pressed?: number; tab?: string; rightChildren?: React.ReactNode }) {
  const steps = runSteps(f);
  const done = f >= 176 + 400;
  return (
    <AppWindow>
      <Shell sidebar={<Sidebar active="matters" compact style={{ paddingTop: 44 }} />}>
        <div className="exec">
          <RunLeft files={["股权转让协议.docx"]} />
          <section className="exec-mid" style={{ overflow: "hidden", paddingTop: 22 }}>
            <div className="exec-head">
              <div>
                <h1 className="page-title" style={{ marginBottom: 6 }}>审合同 · 股权转让协议（受让方）</h1>
                <div className="exec-sub">
                  <span className="pill pill-blue">{done ? "已完成" : f >= RUN_CLICK ? "执行中" : "等你确认"}</span>
                  <span className="pill pill-local">本机处理中</span>
                </div>
              </div>
              <span className="btn-ghost" style={{ fontSize: "var(--fs-sm)" }}>停止任务</span>
            </div>
            <div className="goal-bubble">{HOME_TASK}</div>
            <PlanCard f={f} pressed={pressed} />
            <Timeline
              steps={steps
                .filter((x) => f >= x.at)
                .map((x) => {
                  const p = spr(f, x.at, 170, 22);
                  return { s: x.s, style: { opacity: Math.min(1, p * 1.5), transform: `translateX(${(1 - p) * 12}px)` } };
                })}
            />
          </section>
          <RightPane f={f} tab={tab}>{rightChildren}</RightPane>
        </div>
      </Shell>
    </AppWindow>
  );
}

export function S07Run() {
  const f = useCurrentFrame();
  const press = f >= RUN_CLICK - 3 && f <= RUN_CLICK + 5 ? 1 - Math.abs(f - RUN_CLICK) / 5 : 0;
  return (
    <AbsoluteFill>
      <StudioBackdrop />
      <ProductStage cam={CAM}>
        <RunWindow f={f} pressed={press} />
        <Cursor keys={[{ f: 40, x: 700, y: 640 }, { f: 74, x: 392, y: 380 }, { f: 100, x: 400, y: 392 }]} clicks={[RUN_CLICK]} show={[44, 96]} />
      </ProductStage>
      <Headline at={10} out={90} x={130} y={400} width={560} size={72} title={<>先出计划，<br />再动手。</>} sub="每一步都看得见，随时可以叫停。" />
    </AbsoluteFill>
  );
}
