/**
 * 产品界面复刻：结构与类名逐一对照 platform/apps/desktop/src（Sidebar / Home / Composer / RunView / ReviewWorkbench），
 * 样式直接使用快照的 tokens.css + app.css。这里只做“演示态”数据与动画状态的注入，不另造一套 SaaS 外观。
 * 案例均为虚构（与产品内置示例事项一致：乙投资有限公司受让甲科技有限公司所持丙数据服务有限公司股权）。
 */
import type { CSSProperties, ReactNode } from "react";
import { Icon } from "./Icons";

/* ───────────── 外壳 ───────────── */

const NAV: { key: string; label: string; icon: () => ReactNode }[] = [
  { key: "home", label: "新建任务", icon: Icon.plus },
  { key: "matters", label: "事项", icon: Icon.folder },
  { key: "deliverables", label: "交付件", icon: Icon.file },
  { key: "methods", label: "方法与模板", icon: Icon.book },
  { key: "boards", label: "看板", icon: Icon.board },
  { key: "reminders", label: "期限提醒", icon: Icon.bell },
  { key: "chat", label: "问答", icon: Icon.chat },
  { key: "connections", label: "设置", icon: Icon.plug },
];

export const RECENT = [
  { title: "甲公司股权转让（受让方）", dot: "" as "" | "run" | "wait" },
  { title: "丁建设工程款纠纷（原告）", dot: "" as "" | "run" | "wait" },
  { title: "戊集团年度合规顾问", dot: "" as "" | "run" | "wait" },
  { title: "己公司劳动争议仲裁", dot: "" as "" | "run" | "wait" },
];

export function Sidebar({ active, compact = false, recent = RECENT, activeRecent = -1, badge = 0, foot = "本机运行 · 防护正常", style }: { active: string; compact?: boolean; recent?: typeof RECENT; activeRecent?: number; badge?: number; foot?: string; style?: CSSProperties }) {
  return (
    <aside className={`sidebar${compact ? " compact" : ""}`} style={{ paddingTop: 44, ...style }}>
      <div className="brand">
        <span className="brand-mark" aria-hidden="true">K</span>
        <span>
          Kimi Work
          <small>法律行业发行版</small>
        </span>
      </div>
      <nav className="nav">
        {NAV.map((it) => (
          <div key={it.key} className={`nav-item${active === it.key ? " active" : ""}`}>
            <span className="nav-icon">{it.icon()}</span>
            <span className="nav-label">{it.label}</span>
            {it.key === "deliverables" && badge > 0 && <span className="badge">{badge}</span>}
          </div>
        ))}
      </nav>
      <div className="sidebar-section">最近事项</div>
      <div className="sidebar-list">
        {recent.map((m, i) => (
          <div key={m.title} className={`sidebar-link${activeRecent === i ? " active" : ""}`}>
            {m.dot === "wait" && <span className="act-dot act-wait" />}
            {m.dot === "run" && <span className="act-dot act-run" />}
            {m.title}
          </div>
        ))}
      </div>
      <div className="sidebar-foot">
        <span className="dot dot-ok" />
        <span>{foot}</span>
      </div>
    </aside>
  );
}

export function Shell({ children, sidebar }: { children: ReactNode; sidebar: ReactNode }) {
  return (
    <div className="shell" style={{ width: "100%", height: "100%" }}>
      {sidebar}
      <div className="shell-main" style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", height: "100%", overflow: "hidden" }}>
        {children}
      </div>
    </div>
  );
}

/* ───────────── 输入框 ───────────── */

export function Caret({ on = true }: { on?: boolean }) {
  return <span style={{ display: "inline-block", width: 1.5, height: "1.15em", background: "var(--text-primary)", verticalAlign: "-0.2em", marginLeft: 1, opacity: on ? 1 : 0 }} />;
}

export function Composer({ text, placeholder, caret = false, caretOn = true, chips, matterChip = "未选择事项", sendReady = false, sendPressed = 0, focus = false }: { text: string; placeholder: string; caret?: boolean; caretOn?: boolean; chips?: ReactNode; matterChip?: string; sendReady?: boolean; sendPressed?: number; focus?: boolean }) {
  return (
    <div className="composer" style={focus ? { borderColor: "var(--border-hover)", boxShadow: "0 0 0 4px rgba(22,127,251,0.06), var(--shadow-input)" } : undefined}>
      {chips && <div className="composer-chips">{chips}</div>}
      <div style={{ fontSize: "var(--fs-md)", lineHeight: 1.7, minHeight: 76, padding: 2, color: text ? "var(--text-primary)" : "var(--text-secondary)" }}>
        {text || (caret ? "" : placeholder)}
        {caret && <Caret on={caretOn} />}
        {!text && caret && <span style={{ color: "var(--text-secondary)" }}>{placeholder}</span>}
      </div>
      <div className="composer-bar">
        <span className="tool"><Icon.slash /> <span className="tool-label">方法</span></span>
        <span className="tool"><Icon.at /> <span className="tool-label">材料</span></span>
        <span className="tool"><Icon.attach /> <span className="tool-label">导入</span></span>
        <span className="spacer" />
        <span className="chip"><Icon.folder /> {matterChip}</span>
        <div className="mode-selector">
          <span className="chip">标准（推荐）· 先出计划 <Icon.down /></span>
        </div>
        <span className="send" style={{ opacity: sendReady ? 1 : 0.5, transform: `scale(${1 - sendPressed * 0.1})`, display: "inline-grid" }}>
          <Icon.send />
        </span>
      </div>
    </div>
  );
}

/* ───────────── 首页 ───────────── */

export type Line = "litigation" | "transactional" | "inhouse";
export const LINE_LABEL: Record<Line, string> = { litigation: "诉讼仲裁", transactional: "非诉", inhouse: "企业法务" };

export const SCENARIOS: Record<Line, { title: string; gives: string; gets: string }[]> = {
  litigation: [
    { title: "整理案卷", gives: "起诉材料、证据、往来函件（可多份）", gets: "证据目录.xlsx、事实时间线.xlsx、争点—证据矩阵.xlsx" },
    { title: "金额测算", gives: "合同与付款记录（或直接告诉我本金与日期）", gets: "计算明细.xlsx（分段、公式、起止日）" },
    { title: "起草起诉状", gives: "已整理的事实与金额（建议先做“整理案卷”“金额测算”）", gets: "民事起诉状（草稿）.docx、提交前核对清单" },
    { title: "类案与法律研究", gives: "研究问题（可附材料）", gets: "研究备忘录.docx、来源与引用核验表" },
    { title: "律师函 / 催告函", gives: "合同与往来记录", gets: "函件草稿.docx、发送前核对清单" },
  ],
  transactional: [
    { title: "审合同", gives: "一份合同（Word 最佳）", gets: "逐条审查意见（在审查工作台逐项决定）、带修订痕迹的 Word 修订稿、审查意见书（内部稿）" },
    { title: "回稿比对", gives: "我方基线稿 + 对方回稿（两份 Word）", gets: "回稿比对报告、差异表（含未标修订的静默改动）" },
    { title: "客户版与对外脱敏", gives: "要发出的文件", gets: "脱敏件（无修订痕迹）、脱敏报告" },
    { title: "交易法规研究", gives: "研究问题（可附交易文件）", gets: "研究备忘录.docx、来源与引用核验表" },
    { title: "访谈纪要与材料清单", gives: "访谈录音转写或笔记", gets: "访谈纪要.docx、材料收集清单.xlsx" },
  ],
  inhouse: [
    { title: "合同审核", gives: "一份合同（Word 最佳）", gets: "逐条审核意见（审查工作台）、带修订痕迹的 Word 修订稿" },
    { title: "合规问答 / 顾问答复", gives: "问题（可附业务材料）", gets: "顾问答复.docx（结论、假设、限制）" },
    { title: "履约风险与催告函", gives: "合同与履约记录", gets: "风险提示、催告函草稿.docx" },
    { title: "重大案件进展汇报", gives: "案件材料与最新进展", gets: "管理层一页汇报.docx、进展与风险附表.xlsx" },
    { title: "期限提醒", gives: "事项关键日期", gets: "到期前在这台电脑上提醒" },
  ],
};

export function ScenarioCard({ s, style, hl = false }: { s: { title: string; gives: string; gets: string }; style?: CSSProperties; hl?: boolean }) {
  return (
    <div className="card scenario-card" style={{ ...(hl ? { borderColor: "var(--border-hover)", boxShadow: "var(--shadow-sm)" } : null), ...style }}>
      <div className="title">
        {s.title} <span className="tag tag-beta">试用</span>
      </div>
      <div className="desc">
        <span className="sc-k">给</span>
        <span>{s.gives}</span>
      </div>
      <div className="desc">
        <span className="sc-k">得</span>
        <span>{s.gets}</span>
      </div>
    </div>
  );
}

/** 首页主区。cardIn(i) 返回每张卡的入场样式，方便切换业务线时做形变。 */
export function HomeMain({ line, composer, cardStyle, heroStyle, linesStyle }: { line: Line; composer: ReactNode; cardStyle?: (i: number) => CSSProperties; heroStyle?: CSSProperties; linesStyle?: CSSProperties }) {
  return (
    <main className="main" style={{ overflow: "hidden" }}>
      <div className="main-narrow home">
        <h1 className="hero-title" style={{ marginTop: 92, ...heroStyle }}>今天要处理什么？</h1>
        {composer}
        <section className="lines" style={linesStyle}>
          <div className="section-title">从业务场景开始</div>
          <div className="line-tabs">
            {(Object.keys(LINE_LABEL) as Line[]).map((l) => (
              <span key={l} className={`line-tab${line === l ? " active" : ""}`}>{LINE_LABEL[l]}</span>
            ))}
          </div>
          <div className="cards scenario-cards">
            {SCENARIOS[line].map((s, i) => (
              <ScenarioCard key={line + s.title} s={s} style={cardStyle?.(i)} />
            ))}
            <div className="card scenario-more" style={cardStyle?.(5)}>
              <div className="title">更多场景 →</div>
              <div className="muted">全部方法与模板，按业务线和交付件查找</div>
            </div>
          </div>
          <p className="muted foot-note">所有场景都在试用阶段：结果是草稿，须律师复核后使用。也可以直接在上面描述任务。</p>
        </section>
      </div>
    </main>
  );
}

/* ───────────── 代号（令牌化）胶囊 ───────────── */

export function TokenChip({ kind, code, style }: { kind: string; code: string; style?: CSSProperties }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        borderRadius: "var(--r-xs)",
        padding: "0 6px",
        margin: "0 2px",
        fontSize: "0.92em",
        lineHeight: 1.55,
        background: "var(--paper-mark-person)",
        color: "var(--paper-mark-label-person)",
        fontFamily: "var(--font-mono)",
        letterSpacing: 0,
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      〔{kind}·{code}〕
    </span>
  );
}

/* ───────────── 任务执行三栏 ───────────── */

export type StepState = "done" | "wait" | "pending";
export interface Step {
  title: string;
  detail?: string;
  state: StepState;
  label?: string;
}

export function Timeline({ steps, style }: { steps: { s: Step; style?: CSSProperties }[]; style?: CSSProperties }) {
  return (
    <div className="timeline" style={style}>
      {steps.map(({ s, style: st }, i) => (
        <div key={i} className={`step${s.state === "done" ? " step-ok" : s.state === "wait" ? " step-wait" : ""}`} style={{ display: "flex", gap: 10, padding: "7px 0", ...st }}>
          <span className="step-dot">{s.state === "done" ? <Icon.check /> : null}</span>
          <span className="step-body">
            <span className="step-title">
              {s.label && <span className="tag tag-sub">{s.label}</span>}
              {s.title}
            </span>
            {s.detail && <div className="step-detail">{s.detail}</div>}
          </span>
        </div>
      ))}
    </div>
  );
}

export function RunLeft({ files }: { files: string[] }) {
  return (
    <aside className="exec-left" style={{ paddingTop: 44 }}>
      <div className="btn-link back">← 返回事项</div>
      <div className="pane-title">本次用到的材料</div>
      {files.map((f) => (
        <div key={f} className="mat-row" style={{ display: "flex", gap: 6, alignItems: "center", fontSize: "var(--fs-sm)", padding: "4px 0" }}>
          <span style={{ color: "var(--text-label)", display: "inline-flex" }}><Icon.file /></span>
          <span className="mat-name">{f}</span>
        </div>
      ))}
      <p className="muted">已读 {files.length}/{files.length} 份。</p>
      <div className="pane-title">在哪里处理</div>
      <p className="muted">在这台电脑上处理 · 原件不会被修改 · 结果都是草稿</p>
    </aside>
  );
}

export function RunTabs({ active }: { active: string }) {
  return (
    <div className="tabs">
      {["成果", "文件历史", "数据去向", "引用", "记录"].map((t) => (
        <span key={t} className={`tab${active === t ? " active" : ""}`}>{t}</span>
      ))}
    </div>
  );
}

/* ───────────── 合同与风险卡（审查工作台） ───────────── */

export const CONTRACT = [
  { k: "h", t: "股权转让协议（示例，内容虚构）" },
  { k: "h", t: "第一条　当事人" },
  { k: "p", t: "转让方：甲科技有限公司（示例）" },
  { k: "p", t: "受让方：乙投资有限公司（示例）" },
  { k: "p", t: "目标公司：丙数据服务有限公司（示例）" },
  { k: "h", t: "第二条　转让价款与支付" },
  { k: "p", t: "2.1　目标股权的转让价款为人民币壹仟万元。" },
  { k: "p", t: "2.2　", m: "c1", mt: "受让方应于协议签署后五日内一次性支付全部价款", after: "。" },
  { k: "h", t: "第五条　陈述与保证" },
  { k: "p", t: "5.1　转让方保证目标公司不存在未向受让方披露的债务或担保。" },
  { k: "h", t: "第七条　违约责任" },
  { k: "p", t: "7.1　受让方逾期付款的，", m: "c2", mt: "每日按应付未付金额的千分之五支付违约金", after: "。" },
  { k: "p", t: "7.2　转让方违反陈述与保证的，应赔偿受让方因此遭受的直接损失。" },
  { k: "h", t: "第九条　争议解决" },
  { k: "p", t: "9.1　本协议项下的任何争议，", m: "c3", mt: "提交转让方所在地人民法院诉讼解决", after: "。" },
] as const;

export const CARDS = [
  {
    id: "c1",
    sev: "high" as const,
    sevLabel: "重大",
    ref: "第 2.2 条",
    issue: "价款在股权变更登记之前一次性付清：若之后无法完成变更登记，受让方要先付款再追讨，风险全部在受让方。",
    cat: "法律 + 商业",
    quote: "受让方应于协议签署后五日内一次性支付全部价款",
    suggest: "受让方应于目标股权变更登记完成后五个工作日内支付全部价款",
    basis: [{ law: "民法典", art: "526", state: "source_verified", label: "来源已核" }],
    fallback: "协议签署后支付百分之三十，变更登记完成后支付其余百分之七十",
  },
  {
    id: "c2",
    sev: "mid" as const,
    sevLabel: "一般",
    ref: "第 7.1 条",
    issue: "逾期付款违约金按日千分之五计，明显偏高，且与转让方的违约责任不对等。",
    cat: "法律风险",
    quote: "每日按应付未付金额的千分之五支付违约金",
    suggest: "每日按应付未付金额的万分之五支付违约金，累计不超过转让价款的百分之五",
    basis: [{ law: "民法典", art: "585", state: "version_verified", label: "版本已核" }],
    fallback: "保留日千分之一，并增加累计上限",
  },
  {
    id: "c3",
    sev: "low" as const,
    sevLabel: "提示",
    ref: "第 9.1 条",
    issue: "管辖法院约定在转让方所在地，受让方诉讼成本较高。",
    cat: "商业条件",
    quote: "提交转让方所在地人民法院诉讼解决",
    suggest: "提交原告所在地人民法院诉讼解决",
    basis: [],
    fallback: "",
  },
];

export type CardStatus = "proposed" | "accepted" | "rejected";

export function RiskCard({ c, open, status = "proposed", hover = 0, style }: { c: (typeof CARDS)[number]; open: boolean; status?: CardStatus; hover?: number; style?: CSSProperties }) {
  const cls = c.sev === "high" ? "sev-high" : c.sev === "mid" ? "sev-mid" : "sev-low";
  const statusLabel = status === "accepted" ? "已接受" : status === "rejected" ? "不采纳" : "待处理";
  return (
    <div className={`rc ${cls}${open ? " open" : ""} rc-${status}`} style={style}>
      <div className="rc-head">
        <span className={`rc-sev ${cls}`}>{c.sevLabel}</span>
        <span className="rc-ref">{c.ref}</span>
        <span className="rc-issue">{c.issue}</span>
        <span className={`rc-status rc-status-${status}`}>{statusLabel}</span>
      </div>
      {open && (
        <div className="rc-body">
          <div className="rc-row">
            <span className="rc-k">问题判断</span>
            <span>
              {c.issue}
              <span className="tag tag-gray">{c.cat}</span>
            </span>
          </div>
          <div className="rc-row">
            <span className="rc-k">合同原文</span>
            <span className="rc-quote">{c.quote}</span>
          </div>
          <div className="rc-row">
            <span className="rc-k">建议改为</span>
            <span className="rc-suggest">{c.suggest}</span>
          </div>
          {c.basis.length > 0 && (
            <div className="rc-row">
              <span className="rc-k">依据</span>
              <span>
                {c.basis.map((b) => (
                  <span key={b.art} className="rc-basis">
                    《{b.law}》第 {b.art} 条 <span className={`cite-state cite-${b.state}`}>{b.label}</span>
                  </span>
                ))}
              </span>
            </div>
          )}
          {c.fallback && (
            <div className="rc-row">
              <span className="rc-k">可退让方案</span>
              <span>{c.fallback}</span>
            </div>
          )}
          {status === "proposed" && (
            <div className="rc-actions">
              <span className="btn-primary" style={{ transform: `scale(${1 - hover * 0.06})`, display: "inline-block" }}>接受</span>
              <span className="btn-ghost">修改后接受</span>
              <span className="btn-ghost">不采纳</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/** 合同纸面：被接受的意见以修订痕迹呈现（删除线 + 插入下划线）。 */
export function ContractPaper({ accepted = {}, rejected = {}, active, revealRev = {}, style }: { accepted?: Record<string, boolean>; rejected?: Record<string, boolean>; active?: string; revealRev?: Record<string, number>; style?: CSSProperties }) {
  return (
    <section className="wb-doc" style={style}>
      {CONTRACT.map((p, i) => {
        if (!("m" in p)) return <p key={i} style={p.k === "h" && i === 0 ? { fontWeight: 600, fontSize: "1.08em", marginBottom: 14 } : undefined}>{p.t}</p>;
        const card = CARDS.find((c) => c.id === p.m)!;
        const r = revealRev[p.m] ?? (accepted[p.m] ? 1 : 0);
        const cls = card.sev === "high" ? "mark-high" : card.sev === "mid" ? "mark-mid" : "mark-low";
        return (
          <p key={i}>
            {p.t}
            {r > 0 ? (
              <>
                <span style={{ color: "var(--status-danger-text)", textDecoration: "line-through", textDecorationThickness: 1.5, opacity: 0.85 }}>{p.mt}</span>
                <span style={{ color: "var(--accent-text)", textDecoration: "underline", textDecorationColor: "var(--accent)", textDecorationThickness: 1.5, textUnderlineOffset: 4 }}>
                  {Array.from(card.suggest).slice(0, Math.ceil(r * Array.from(card.suggest).length)).join("")}
                </span>
              </>
            ) : (
              <mark className={`wb-mark ${cls}${rejected[p.m] ? " mark-rejected" : ""}${active === p.m ? " mark-active" : ""}`}>{p.mt}</mark>
            )}
            {p.after}
          </p>
        );
      })}
    </section>
  );
}
