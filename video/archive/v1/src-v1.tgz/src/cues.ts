/**
 * 动作提示点（唯一出处）：画面里的点击、打字、出现与配乐/音效共用同一组帧号。
 * 场景内帧号为该场景的局部帧；GLOBAL_CUES 换算为全片帧，供 scripts/make-music.mjs 生成音效。
 * 点击都落在拍点上（1 拍 = 16 帧）。
 */
import { BEAT, SCENES } from "./timeline.ts";

export const HOME_TASK = "审查这份股权转让协议，我方为受让方，重点关注付款与违约责任";
export const HOME_TYPE_AT = 52;
export const HOME_TYPE_CPS = 13;
export const HOME_CLICK = 208;
export const PRIVACY_CLICK = 176;
export const PRIVACY_REDACT = [58, 70, 82];
export const RUN_CLICK = 80;
export const RUN_STEP_DONE = [112, 144, 176];
export const CITE_CLICK = 16;
export const CITE_RESOLVE = [40, 56, 80];
export const C1_ACCEPT = 112;
export const C2_ACCEPT = 192;
export const C3_REJECT = 224;
export const REDLINE_CLICK = 256;
export const UNIFY_MERGE = 132;
export const SCATTER_APPEAR = Array.from({ length: 12 }, (_, k) => (k < 8 ? 8 + k * BEAT : 8 + 8 * BEAT + (k - 8) * (BEAT / 2)));

const g = (scene: keyof typeof SCENES, f: number) => SCENES[scene].from + f;

export type CueType = "type" | "click" | "whoosh" | "pop" | "blip" | "warn" | "tick";
export const GLOBAL_CUES: { f: number; type: CueType; v?: number }[] = [
  ...SCATTER_APPEAR.map((f, i) => ({ f: g("scatter", f), type: "tick" as const, v: 0.5 + i * 0.03 })),
  ...Array.from(HOME_TASK).map((_, i) => ({ f: g("home", HOME_TYPE_AT + Math.floor((i * 30) / HOME_TYPE_CPS)), type: "type" as const })),
  { f: g("home", HOME_CLICK), type: "click" },
  ...PRIVACY_REDACT.map((f, i) => ({ f: g("privacy", f + 22), type: "pop" as const, v: i })),
  { f: g("privacy", PRIVACY_CLICK), type: "click" },
  { f: g("run", RUN_CLICK), type: "click" },
  ...RUN_STEP_DONE.map((f, i) => ({ f: g("run", f), type: "blip" as const, v: i })),
  { f: g("cite", CITE_CLICK), type: "click" },
  { f: g("cite", CITE_RESOLVE[0]), type: "blip", v: 1 },
  { f: g("cite", CITE_RESOLVE[1]), type: "blip", v: 2 },
  { f: g("cite", CITE_RESOLVE[2]), type: "warn" },
  { f: g("review", C1_ACCEPT), type: "click" },
  { f: g("review", C2_ACCEPT), type: "click" },
  { f: g("review", C3_REJECT), type: "click" },
  { f: g("review", REDLINE_CLICK), type: "click" },
  { f: g("review", REDLINE_CLICK + 10), type: "whoosh", v: 0.6 },
  { f: g("scatter", 0), type: "whoosh", v: 0.35 },
  { f: g("converge", 20), type: "whoosh", v: 0.8 },
  { f: g("run", 0) - 6, type: "whoosh", v: 0.45 },
  { f: g("review", 0) - 6, type: "whoosh", v: 0.45 },
  { f: g("unify", 0) - 6, type: "whoosh", v: 0.5 },
  { f: g("unify", UNIFY_MERGE), type: "whoosh", v: 0.7 },
  { f: g("trust", 0) - 6, type: "whoosh", v: 0.4 },
];
